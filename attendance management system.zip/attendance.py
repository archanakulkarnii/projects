import mysql.connector
from mysql.connector import Error

def create_connection():
    """ Create a connection to the MySQL database """
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='student_attendance',
            user='roopa',     # Replace with your MySQL username
            password='roopashankar@123'  # Replace with your MySQL password
        )
        if connection.is_connected():
            print('Successfully connected to the database')
            return connection
    except Error as e:
        print(f"Error: {e}")
        return None

def add_attendance(connection, attendance_date, student_id, status, comments):
    """ Add a record to the attendance table """
    try:
        cursor = connection.cursor()
        sql = "INSERT INTO attendance (attendance_date, student_id, status, comments) VALUES (%s, %s, %s, %s)"
        values = (attendance_date, student_id, status, comments)
        cursor.execute(sql, values)
        connection.commit()
        print('Attendance record added successfully')
    except Error as e:
        print(f"Error: {e}")

def view_attendance(connection):
    """ Retrieve and print all records from the attendance table """
    try:
        cursor = connection.cursor()
        sql = "SELECT * FROM attendance"
        cursor.execute(sql)
        rows = cursor.fetchall()
        for row in rows:
            print(row)
    except Error as e:
        print(f"Error: {e}")

def main():
    connection = create_connection()
    if connection:
        while True:
            # Get user input for the attendance record
            attendance_date = input("Enter attendance date (YYYY-MM-DD): ")
            student_id = input("Enter student ID: ")
            status = input("Enter status (Present/Absent): ")
            comments = input("Enter comments: ")
            
            # Add the attendance record
            add_attendance(connection, attendance_date, student_id, status, comments)
            
            # Optionally, view all records
            view_choice = input("Do you want to view all attendance records? (yes/no): ")
            if view_choice.lower() == 'yes':
                view_attendance(connection)
            
            # Ask if the user wants to continue adding records
            continue_choice = input("Do you want to add another record? (yes/no): ")
            if continue_choice.lower() != 'yes':
                break
        
        # Close the connection
        connection.close()

if __name__ == "_main_":
    main()